# Hackintosh
HackIntosh of GIGABYT EB250M +I5 7500+HD630+ALC887

# 该配置为黑苹果EFI for I57500+技嘉M250+集成显卡HD630+ALC887声卡的配置
