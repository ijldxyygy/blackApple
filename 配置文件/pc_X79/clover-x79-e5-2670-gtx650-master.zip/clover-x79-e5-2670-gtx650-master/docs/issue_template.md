## 提问须知

提问前，请先阅读 [README.md](https://github.com/cheneyveron/clover-x79-e5-2670-gtx650/blob/master/README.md) 和 [进阶说明](https://github.com/cheneyveron/clover-x79-e5-2670-gtx650/blob/master/docs/变更说明.md)
，并升级到我最新的EFI。

如果都无法解决问题，请删掉**提问须知**，并修改下面的模板。

## 提问模板

- **系统版本**: 10.13.4

- **BIOS版本**: 2.47

- **主板版本**: 2.46

- **-v图**: 

【假装有图片】

- **已经采取过而无效的方法**: 

使用了 [这儿](https://github.com/vit9696/AppleALC) 中最新的AppleALC替换了EFI/Clover/Kexts/Other中的AppleALC.kext，问题依旧。
